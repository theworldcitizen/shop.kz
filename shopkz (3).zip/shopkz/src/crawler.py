import json
from typing import List

import requests
from bs4 import BeautifulSoup

from models import Ad

HEADERS = {
    'authority': 'shop.kz',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
    'referer': 'https://shop.kz/almaty/offers/smartfony/?PAGEN_1=2',
    'sec-ch-ua': '"Google Chrome";v="105", "Not)A;Brand";v="8", "Chromium";v="105"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Linux"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
}


class Crawler:
    output = []
    cnt = 0

    @staticmethod
    def make_request(link):
        response = requests.get(link, headers=HEADERS)
        if response.ok:
            return response.text

    @staticmethod
    def make_soup(html):
        soup = BeautifulSoup(html, 'html.parser')
        return soup

    @staticmethod
    def get_title(soup: BeautifulSoup):
        try:
            name = soup.find('h1', class_='bx-title dbg_title').text.strip()
            return name
        except Exception:
            return None

    @staticmethod
    def get_articul(soup: BeautifulSoup):
        try:
            div = soup.find('div', class_='bx_item_container')
            div = div.find('div', class_='row')
            ul = div.find('ul', class_='bx-card-mark col-lg-4 col-xs-12 col-sm-6')
            items = ul.find_all('li')
            li = items[0].text.split()
            articul = li[-1]
            return articul
        except Exception:
            return None

    @staticmethod
    def get_price(soup: BeautifulSoup):
        try:
            price = soup.find('div', class_='item_current_price').text
            return price
        except Exception:
            return None

    @staticmethod
    def get_memory_size(soup: BeautifulSoup):
        try:
            div = soup.find('dl', class_='bx_detail_chars')
            divs = div.find_all('div', class_='bx_detail_chars_i')
            for di in divs:
                i = di.find('dt', class_='bx_detail_chars_i_title')
                span = i.find('span', class_='glossary-term')
                name_of_field = span.text
                if name_of_field == 'Объем встроенной памяти':
                    memory = di.find('dd', class_='bx_detail_chars_i_field').text
                    return memory
        except Exception as e:
            print(f'Exception accused: {e}')
            return None

    def get_info(self, links):

        for link in links:
            html = self.make_request(link)
            soup = self.make_soup(html)
            name = self.get_title(soup)
            articul = self.get_articul(soup)
            price = self.get_price(soup)
            memory_size = self.get_memory_size(soup)

            res = Ad(name=name, price=price, articul=articul, memory_size=memory_size, link=link).model_dump()

            self.output.append(res)

        return

    def get_all_links(self, soup: BeautifulSoup):
        links = []
        div = soup.find('div', class_='bx_catalog_list_home list bx_blue')
        all_items = div.find_all('div', class_='bx_catalog_item gtm-impression-product')
        for item in all_items:
            link = item.find('div', class_='item_image_container').find('a')['href']
            links.append('https://shop.kz' + link)
            self.cnt += 1
        print(f'collected {self.cnt} items')
        return links

    @staticmethod
    def get_pagination(soup: BeautifulSoup):
        div = soup.find('div', class_='bx-pagination bx-blue')
        main_div = div.find('div', class_='bx-pagination-container row')
        ul = main_div.find('ul')
        items = ul.find_all('li')
        item = items[-1]
        try:
            a = item.find('a')
            if a is None:
                return
            url = a.get('href')
            return url
        except Exception as e:
            print(f'Exception accused: {e}')
            return

    def loop(self, soup):
        links = self.get_all_links(soup)
        self.get_info(links)
        return self.get_pagination(soup)

    @staticmethod
    def write_to_file(data):
        print('we are here')
        with open('smartphones.json', 'a') as file:
            json.dump(data, file, indent=5)
            file.close()

    def main(self, link):
        html = self.make_request(link)
        soup = self.make_soup(html)
        print(f'STARTING: {link}')
        link = self.loop(soup)
        while True:
            link = 'https://shop.kz' + link
            html = self.make_request(link)
            soup = self.make_soup(html)
            print(f'STARTING: {link}')
            link = self.loop(soup)
            break
            # if link == 'https://shop.kz/almaty/offers/smartfony/?PAGEN_1=3':
            #     break
        print(f'Going to write to files')
        return self.write_to_file(self.output)


if __name__ == '__main__':
    crawler = Crawler()
    crawler.main('https://shop.kz/almaty/offers/smartfony/')
